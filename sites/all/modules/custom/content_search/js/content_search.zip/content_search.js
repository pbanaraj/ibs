(function ($) {

  Drupal.behaviors.content_search = {
    attach: function (context) {
      
      $("[id^='edit-content-search']").focus(
        function(){
          $(this).val('');
      });

      $("[id^='edit-content-search']", context).unbind('autocompleteSelect').bind('autocompleteSelect', function(event, node) {
        
        var key = $(node).data('autocompleteValue');
        var label = $(node).text();
        
        // If matches found...
        if (key != '0') {
          
          // Set the value of this field.
          $(this).val(label);		  
		  var url  = Drupal.settings.basePath + '/modal_display/node/nojs/'+key;
		  var link = $("<a></a>").attr('href', url).addClass('use-ajax ctools-modal-ctools-custom-style ctools-use-modal-processed').click(Drupal.CTools.Modal.clickAjaxLink);
		  Drupal.ajax[url] = new Drupal.ajax(url, link.get(0), {
			  url: url,
			  event: 'click',
			  progress: { type: 'throbber' }
			});
			link.click();         
        }
        else {
          
          // If no matches, reset.
          $(this).val('');
          $(this).focus();
        }
      });
    }
  };

})(jQuery);